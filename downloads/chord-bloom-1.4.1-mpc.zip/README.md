# Chord Bloom

A one-finger chord instrument for Akai MPC standalone hardware, by N8b. Inspired by
chord-synth instruments where one hand picks the chord type and the other plays roots.

Hold a chord type and play a root note: you get a full, voiced chord through a built-in
pad / keys synth with chorus. Block chords, strums or a tempo-synced arpeggio.

## Requirements

- MPC OS 3.10.1 or later.
- Preferences → Enhancements (Beta): turn on **Enable Enhancements** and **External Plugin Support**.

## Playing on pads (default: Chord Keys = Pads, Chord Mode = In Key)

Pad bank A, with the bottom-left pad as the first chord pad (set it with Pad Learn: turn it on, hit that pad):

| Row | Pads |
|---|---|
| Top | degree 5, 6, 7, 8 (octave) |
| 3rd | degree 1, 2, 3, 4 of Key/Scale |
| 2nd | add 6, add m7, add maj7, add 9 |
| Bottom | Dim, Min, Maj, Sus4 |

Tap a degree pad alone for the in-key chord; hold chord pads to change it. Other pad banks play chords on the notes they send.

## Playing on a keyboard (Chord Keys = Keys)

**Chord keys** (CHORD page → Chord Keys = White Keys, Zone Start = C1):

| Key | C1 | D1 | E1 | F1 | G1 | A1 | B1 | C2 |
|---|---|---|---|---|---|---|---|---|
| Does | Dim | Min | Maj | Sus4 | add 6 | add m7 | add maj7 | add 9 |

Hold one or more of them with your left hand and play roots anywhere above C2 with the right.
Combine: Min + m7 = m7, Min + m7 + 9 = m9, Maj + maj7 = maj7, Dim + m7 = m7b5, Dim + 6 = dim7.
With no chord key held, the CHORD page's Chord and Add switches decide. Black keys in the
zone are silent. "Chrom" puts the 8 chord keys on 8 adjacent notes (handy on pads).
**Key Latch** makes the last chord-key combination stick after you let go.

**Chord Mode = In Key**: every root in the chosen Key/Scale plays its diatonic chord
(e.g. in C major: D → Dm, G → G, B → Bdim; the Add 6/7/9 switches add diatonic notes).
Holding a triad chord key still overrides the quality.

## Parameters

| Page | Controls |
|---|---|
| PERFORM | Filter (left = low-pass sweep, right = high-pass), Delay (tempo-synced ping-pong send), Reverb, Drive, Delay Time, Feedback, Room Size, Verb Tone, Chorus, Chorus Rate, Chorus Depth, Volume |
| CHORD | Chord, Chord Mode (Manual / In Key), Key, Scale, Add 6 / m7 / maj7 / 9, Chord Keys (Off / Keys / Chrom / Pads), Zone Start, Pad Learn, Key Latch |
| VOICING | Inversion (0-3), Voicing (Close / Drop 2 / Open / Wide), Voice Lead (picks the inversion closest to the last chord), Octave, Bass Note (Off / -1 / -2 octaves) |
| PLAY | Play Mode (Chord / Strum / Arp), Strum Time (total, ms), Strum Dir (Up / Down / Alternate), Humanize, Arp Rate (synced to the MPC tempo; locked to the grid while playing), Arp Dir, Arp Gate, Arp Octaves |
| SOUND | Brightness, Resonance, Filter Env, Velocity, Engine (Analog / Keys FM), Wave, Detune, Tine (FM bite for Keys), Attack, Decay, Sustain, Release |

Sustain pedal (CC64) holds the chord; pitch bend is ±2 semitones; last-note priority for roots.

Presets: Bloom Pad, Strum Harp, Neo Soul Keys, In-Key Arp, Glass Keys, Dark Strings.

## Q-Link knobs

The PERFORM page opens first; its left column (Filter, Delay, Reverb, Drive) is the first Q-Link bank. In the MPC's Program Q-Link mode the knobs always control, in order: Filter, Delay, Reverb, Drive, Feedback, Room Size, Chorus, Brightness, Delay Time, Verb Tone, Strum Time, Humanize, Attack, Release, Resonance, Volume, whatever page is on screen (set by `post_build.py` after the build).

## Honest notes

- 16 voices. Big chords with long releases on the Analog engine are the heaviest case; on a
  32-bit MPC (One, Live II, Key 61...) watch the CPU meter and shorten Release or use Keys if it climbs.
- Plugins on the MPC cannot send MIDI, so the chords play through this plugin's own synth,
  not through other MPC instruments.
- Tested in the SDK host simulator (all checks pass); not yet tested on hardware.

## Build

```
python tools/build.py plugins/ChordBloom
python plugins/ChordBloom/post_build.py
python tools/package.py plugins/ChordBloom
```
MIT licence.
